import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';

export const errorRate = new Rate('errors');
export const options = {
  // k6 run --vus 10 --duration 30s script.js
  stages: [
    { duration: '5m', target: 1000 }, // simulate ramp-up of traffic from 1 to 60 users over 5 minutes.
    { duration: '10m', target: 1000 }, // stay at 60 users for 10 minutes
    { duration: '3m', target: 2000 }, // ramp-up to 100 users over 3 minutes (peak hour starts)
    { duration: '2m', target: 2000 }, // stay at 100 users for short amount of time (peak hour)
    { duration: '3m', target: 1000 }, // ramp-down to 60 users over 3 minutes (peak hour ends)
    { duration: '10m', target: 1000 }, // continue at 60 for additional 10 minutes
    { duration: '5m', target: 0 }, // ramp-down to 0 users
  ],
  thresholds: {
    http_req_duration: ['p(99)<1500'], // 99% of requests must complete below 1.5s
  },
};
export default function () {
  const url = 'http://103.13.207.248/apidocs/here/';
  
  const params = {
    headers: {
      'Content-Type': 'application/json',
    },
  };
  check(http.get(url, params), {
    'status is 200': (r) => r.status == 200,
  }) || errorRate.add(1);
}